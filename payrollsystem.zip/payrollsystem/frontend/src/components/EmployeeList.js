import React from 'react';

function EmployeeList({ employees, onDelete, onBlock, onUnblock, onManageSalary }) {
  return (
    <div className="table-container">
      <table>
        <thead>
          <tr>
            <th>Employee ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Designation</th>
            <th>Hours Worked</th>
            <th>Bonus ($)</th>
            <th>Extra Hours</th>
            <th>Total Salary ($)</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {employees.length === 0 ? (
            <tr>
              <td colSpan="10" style={{ textAlign: 'center', padding: '20px' }}>
                No employees found. Create your first employee!
              </td>
            </tr>
          ) : (
            employees.map((employee) => (
              <tr key={employee.id}>
                <td>{employee.employee_id}</td>
                <td>{employee.name}</td>
                <td>{employee.email}</td>
                <td>{employee.designation}</td>
                <td>{employee.designation === 'Part-Time' ? employee.hours_worked : 'N/A'}</td>
                <td>{employee.bonus.toFixed(2)}</td>
                <td>{employee.extra_hours}</td>
                <td><strong>${employee.total_salary.toFixed(2)}</strong></td>
                <td>
                  {employee.is_blocked ? (
                    <span className="blocked-badge">Blocked</span>
                  ) : (
                    <span className="active-badge">Active</span>
                  )}
                </td>
                <td>
                  <div className="action-buttons">
                    <button
                      onClick={() => onManageSalary(employee)}
                      className="btn btn-primary btn-small"
                    >
                      Manage Salary
                    </button>
                    
                    {employee.is_blocked ? (
                      <button
                        onClick={() => onUnblock(employee.employee_id)}
                        className="btn btn-success btn-small"
                      >
                        Unblock
                      </button>
                    ) : (
                      <button
                        onClick={() => onBlock(employee.employee_id)}
                        className="btn btn-warning btn-small"
                      >
                        Block
                      </button>
                    )}
                    
                    <button
                      onClick={() => onDelete(employee.employee_id)}
                      className="btn btn-danger btn-small"
                    >
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default EmployeeList;