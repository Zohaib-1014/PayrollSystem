import React, { useState } from 'react';
import ApiService from '../services/api';

function SalaryManagement({ token, employee, onClose, onSuccess }) {
  const [formData, setFormData] = useState({
    bonus: employee.bonus || 0,
    extra_hours: employee.extra_hours || 0,
    hours_worked: employee.hours_worked || 0,
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: parseFloat(e.target.value) || 0,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const updateData = {
        bonus: formData.bonus,
        extra_hours: formData.extra_hours,
      };

      if (employee.designation === 'Part-Time') {
        updateData.hours_worked = formData.hours_worked;
      }

      await ApiService.updateIncentives(token, employee.employee_id, updateData);
      onSuccess();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal">
        <h3>Manage Salary - {employee.name}</h3>
        <p style={{ color: '#666', marginBottom: '20px' }}>
          Employee ID: {employee.employee_id} | Designation: {employee.designation}
        </p>

        {error && <div className="error-message">{error}</div>}

        <form onSubmit={handleSubmit}>
          {employee.designation === 'Part-Time' && (
            <div className="form-group">
              <label>Hours Worked:</label>
              <input
                type="number"
                name="hours_worked"
                value={formData.hours_worked}
                onChange={handleChange}
                min="0"
                step="0.5"
              />
              <small style={{ color: '#666' }}>Hourly Rate: $15/hour</small>
            </div>
          )}

          <div className="form-group">
            <label>Bonus ($):</label>
            <input
              type="number"
              name="bonus"
              value={formData.bonus}
              onChange={handleChange}
              min="0"
              step="0.01"
              placeholder="Enter bonus amount"
            />
          </div>

          <div className="form-group">
            <label>Extra Hours (Overtime):</label>
            <input
              type="number"
              name="extra_hours"
              value={formData.extra_hours}
              onChange={handleChange}
              min="0"
              step="0.5"
              placeholder="Enter extra hours"
            />
            <small style={{ color: '#666' }}>Overtime Rate: $20/hour</small>
          </div>

          <div style={{ background: '#f8f9fa', padding: '15px', borderRadius: '5px', marginTop: '20px' }}>
            <h4>Current Salary Information:</h4>
            <p>Base Salary: ${employee.designation === 'Full-Time' ? '3000.00' : (employee.hours_worked * 15).toFixed(2)}</p>
            <p>Current Bonus: ${employee.bonus.toFixed(2)}</p>
            <p>Current Extra Hours: {employee.extra_hours}</p>
            <p><strong>Current Total: ${employee.total_salary.toFixed(2)}</strong></p>
          </div>

          <div className="modal-buttons">
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Updating...' : 'Update Salary'}
            </button>
            <button type="button" onClick={onClose} className="btn btn-secondary">
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default SalaryManagement;