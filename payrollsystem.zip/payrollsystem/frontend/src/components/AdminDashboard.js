import React, { useState, useEffect, useCallback } from 'react';
import ApiService from '../services/api';
import CreateEmployee from './CreateEmployee';
import SalaryManagement from './SalaryManagement';
import EmployeeList from './EmployeeList';

function AdminDashboard({ onLogout }) {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showSalaryModal, setShowSalaryModal] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const user = JSON.parse(localStorage.getItem('user'));

  const fetchEmployees = useCallback(async () => {
    try {
      setLoading(true);
      const data = await ApiService.getAllEmployees(user.access_token);
      setEmployees(data);
      setError('');
    } catch (err) {
      setError('Failed to fetch employees');
    } finally {
      setLoading(false);
    }
  }, [user.access_token]);

  useEffect(() => {
    fetchEmployees();
  }, [fetchEmployees]);

  const handleEmployeeCreated = () => {
    setShowCreateModal(false);
    fetchEmployees();
    setSuccessMessage('Employee created successfully!');
    setTimeout(() => setSuccessMessage(''), 3000);
  };

  const handleDeleteEmployee = async (employeeId) => {
    if (window.confirm('Are you sure you want to delete this employee?')) {
      try {
        await ApiService.deleteEmployee(user.access_token, employeeId);
        fetchEmployees();
        setSuccessMessage('Employee deleted successfully!');
        setTimeout(() => setSuccessMessage(''), 3000);
      } catch (err) {
        setError('Failed to delete employee');
      }
    }
  };

  const handleBlockEmployee = async (employeeId) => {
    try {
      await ApiService.blockEmployee(user.access_token, employeeId);
      fetchEmployees();
      setSuccessMessage('Employee blocked successfully!');
      setTimeout(() => setSuccessMessage(''), 3000);
    } catch (err) {
      setError('Failed to block employee');
    }
  };

  const handleUnblockEmployee = async (employeeId) => {
    try {
      await ApiService.unblockEmployee(user.access_token, employeeId);
      fetchEmployees();
      setSuccessMessage('Employee unblocked successfully!');
      setTimeout(() => setSuccessMessage(''), 3000);
    } catch (err) {
      setError('Failed to unblock employee');
    }
  };

  const handleManageSalary = (employee) => {
    setSelectedEmployee(employee);
    setShowSalaryModal(true);
  };

  const handleSalaryUpdated = () => {
    setShowSalaryModal(false);
    fetchEmployees();
    setSuccessMessage('Salary updated successfully!');
    setTimeout(() => setSuccessMessage(''), 3000);
  };

  return (
    <div className="container">
      <div className="dashboard">
        <div className="dashboard-header">
          <h1>Admin Dashboard</h1>
          <button onClick={onLogout} className="btn btn-secondary">
            Logout
          </button>
        </div>

        {error && <div className="error-message">{error}</div>}
        {successMessage && <div className="success-message">{successMessage}</div>}

        <div>
          <button 
            onClick={() => setShowCreateModal(true)} 
            className="btn btn-primary"
          >
            + Create New Employee
          </button>
        </div>

        {loading ? (
          <div className="loading">Loading employees...</div>
        ) : (
          <EmployeeList
            employees={employees}
            onDelete={handleDeleteEmployee}
            onBlock={handleBlockEmployee}
            onUnblock={handleUnblockEmployee}
            onManageSalary={handleManageSalary}
          />
        )}
      </div>

      {showCreateModal && (
        <CreateEmployee
          token={user.access_token}
          onClose={() => setShowCreateModal(false)}
          onSuccess={handleEmployeeCreated}
        />
      )}

      {showSalaryModal && selectedEmployee && (
        <SalaryManagement
          token={user.access_token}
          employee={selectedEmployee}
          onClose={() => setShowSalaryModal(false)}
          onSuccess={handleSalaryUpdated}
        />
      )}
    </div>
  );
}

export default AdminDashboard;