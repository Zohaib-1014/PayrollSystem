import React, { useState, useEffect, useCallback } from 'react';
import ApiService from '../services/api';

function EmployeeDashboard({ user, onLogout }) {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchProfile = useCallback(async () => {
    try {
      setLoading(true);
      const data = await ApiService.getEmployeeProfile(user.access_token, user.employee_id);
      setProfile(data);
      setError('');
    } catch (err) {
      setError('Failed to fetch profile');
    } finally {
      setLoading(false);
    }
  }, [user.access_token, user.employee_id]);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  if (loading) {
    return (
      <div className="container">
        <div className="loading">Loading your profile...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container">
        <div className="error-message">{error}</div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="dashboard">
        <div className="dashboard-header">
          <h1>Employee Dashboard</h1>
          <button onClick={onLogout} className="btn btn-secondary">
            Logout
          </button>
        </div>

        {profile.is_blocked && (
          <div className="error-message">
            ⚠️ Your account is currently blocked. Please contact administrator.
          </div>
        )}

        <div className="profile-card">
          <h2>My Profile</h2>
          
          <div className="profile-item">
            <span className="profile-label">Employee ID:</span>
            <span className="profile-value">{profile.employee_id}</span>
          </div>

          <div className="profile-item">
            <span className="profile-label">Name:</span>
            <span className="profile-value">{profile.name}</span>
          </div>

          <div className="profile-item">
            <span className="profile-label">Email:</span>
            <span className="profile-value">{profile.email}</span>
          </div>

          <div className="profile-item">
            <span className="profile-label">Designation:</span>
            <span className="profile-value">{profile.designation}</span>
          </div>

          <div className="profile-item">
            <span className="profile-label">Account Status:</span>
            <span className="profile-value">
              {profile.is_blocked ? (
                <span className="blocked-badge">Blocked</span>
              ) : (
                <span className="active-badge">Active</span>
              )}
            </span>
          </div>
        </div>

        <div className="salary-breakdown">
          <h3>Salary Breakdown</h3>
          
          {profile.designation === 'Full-Time' ? (
            <>
              <div className="salary-item">
                <span>Base Salary (Monthly):</span>
                <span>${profile.salary_breakdown.base_salary.toFixed(2)}</span>
              </div>
              <div className="salary-item">
                <span>Bonus:</span>
                <span>${profile.salary_breakdown.bonus.toFixed(2)}</span>
              </div>
              <div className="salary-item">
                <span>Extra Hours ({profile.salary_breakdown.extra_hours} hrs @ $20/hr):</span>
                <span>${profile.salary_breakdown.overtime_pay.toFixed(2)}</span>
              </div>
            </>
          ) : (
            <>
              <div className="salary-item">
                <span>Hourly Rate:</span>
                <span>${profile.salary_breakdown.hourly_rate.toFixed(2)}/hr</span>
              </div>
              <div className="salary-item">
                <span>Hours Worked:</span>
                <span>{profile.salary_breakdown.hours_worked} hours</span>
              </div>
              <div className="salary-item">
                <span>Base Pay:</span>
                <span>${profile.salary_breakdown.base_pay.toFixed(2)}</span>
              </div>
              <div className="salary-item">
                <span>Bonus:</span>
                <span>${profile.salary_breakdown.bonus.toFixed(2)}</span>
              </div>
              <div className="salary-item">
                <span>Extra Hours ({profile.salary_breakdown.extra_hours} hrs @ $20/hr):</span>
                <span>${profile.salary_breakdown.overtime_pay.toFixed(2)}</span>
              </div>
            </>
          )}
          
          <div className="salary-item">
            <span>Total Salary:</span>
            <span>${profile.salary_breakdown.total_salary.toFixed(2)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EmployeeDashboard;