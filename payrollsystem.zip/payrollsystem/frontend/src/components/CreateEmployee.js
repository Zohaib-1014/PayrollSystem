import React, { useState } from 'react';
import ApiService from '../services/api';

function CreateEmployee({ token, onClose, onSuccess }) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    designation: 'Full-Time',
    hours_worked: 0,
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [credentials, setCredentials] = useState(null);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await ApiService.createEmployee(token, formData);
      setCredentials(response);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    if (credentials) {
      onSuccess();
    } else {
      onClose();
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal">
        <h3>Create New Employee</h3>

        {error && <div className="error-message">{error}</div>}

        {credentials ? (
          <div className="credentials-box">
            <h4>Employee Created Successfully!</h4>
            <p><strong>Employee ID:</strong> {credentials.employee_id}</p>
            <p><strong>Password:</strong> {credentials.password}</p>
            <p><strong>Name:</strong> {credentials.name}</p>
            <p><strong>Email:</strong> {credentials.email}</p>
            <p style={{ marginTop: '15px', color: '#dc3545' }}>
              ⚠️ Please save these credentials. The password cannot be retrieved later!
            </p>
            <button onClick={handleClose} className="btn btn-primary" style={{ marginTop: '20px' }}>
              Close
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Name:</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Enter employee name"
                required
              />
            </div>

            <div className="form-group">
              <label>Email:</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="Enter email address"
                required
              />
            </div>

            <div className="form-group">
              <label>Designation:</label>
              <select
                name="designation"
                value={formData.designation}
                onChange={handleChange}
              >
                <option value="Full-Time">Full-Time</option>
                <option value="Part-Time">Part-Time</option>
              </select>
            </div>

            {formData.designation === 'Part-Time' && (
              <div className="form-group">
                <label>Hours Worked:</label>
                <input
                  type="number"
                  name="hours_worked"
                  value={formData.hours_worked}
                  onChange={handleChange}
                  min="0"
                  step="0.5"
                  placeholder="Enter hours worked"
                />
              </div>
            )}

            <div className="modal-buttons">
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? 'Creating...' : 'Create Employee'}
              </button>
              <button type="button" onClick={onClose} className="btn btn-secondary">
                Cancel
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

export default CreateEmployee;