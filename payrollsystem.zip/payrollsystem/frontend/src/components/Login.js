import React, { useState } from 'react';
import ApiService from '../services/api';

function Login({ onLogin }) {
  const [loginType, setLoginType] = useState('admin'); // 'admin' or 'employee'
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    employeeId: '',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      let response;
      
      if (loginType === 'admin') {
        response = await ApiService.adminLogin(formData.email, formData.password);
      } else {
        response = await ApiService.employeeLogin(formData.employeeId, formData.password);
      }

      onLogin(response);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <h2>Payroll System Login</h2>

        <div className="form-group">
          <label>Login As:</label>
          <select 
            value={loginType} 
            onChange={(e) => {
              setLoginType(e.target.value);
              setError('');
              setFormData({ email: '', password: '', employeeId: '' });
            }}
          >
            <option value="admin">Admin</option>
            <option value="employee">Employee</option>
          </select>
        </div>

        {error && <div className="error-message">{error}</div>}

        <form onSubmit={handleSubmit}>
          {loginType === 'admin' ? (
            <>
              <div className="form-group">
                <label>Email:</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="admin@payroll.com"
                  required
                />
              </div>
              <div className="form-group">
                <label>Password:</label>
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="Enter password"
                  required
                />
              </div>
            </>
          ) : (
            <>
              <div className="form-group">
                <label>Employee ID:</label>
                <input
                  type="text"
                  name="employeeId"
                  value={formData.employeeId}
                  onChange={handleChange}
                  placeholder="EMP001"
                  required
                />
              </div>
              <div className="form-group">
                <label>Password:</label>
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="Enter password"
                  required
                />
              </div>
            </>
          )}

          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? 'Logging in...' : 'Login'}
          </button>
        </form>

        {loginType === 'admin' && (
          <div style={{ marginTop: '20px', textAlign: 'center', fontSize: '14px', color: '#666' }}>
            
          </div>
        )}
      </div>
    </div>
  );
}

export default Login;