const API_URL = 'http://localhost:8000';

class ApiService {
  // Admin login
  static async adminLogin(email, password) {
    const response = await fetch(`${API_URL}/admin/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password }),
    });

    if (!response.ok) {
      throw new Error('Invalid credentials');
    }

    return await response.json();
  }

  // Employee login
  static async employeeLogin(employeeId, password) {
    const response = await fetch(`${API_URL}/employee/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ 
        employee_id: employeeId, 
        password 
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Login failed');
    }

    return await response.json();
  }

  // Get all employees (Admin)
  static async getAllEmployees(token) {
    const response = await fetch(`${API_URL}/admin/employees`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch employees');
    }

    return await response.json();
  }

  // Create employee (Admin)
  static async createEmployee(token, employeeData) {
    const response = await fetch(`${API_URL}/admin/employees`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify(employeeData),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Failed to create employee');
    }

    return await response.json();
  }

  // Update incentives (Admin)
  static async updateIncentives(token, employeeId, incentives) {
    const response = await fetch(`${API_URL}/admin/employees/${employeeId}/incentives`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify(incentives),
    });

    if (!response.ok) {
      throw new Error('Failed to update incentives');
    }

    return await response.json();
  }

  // Block employee (Admin)
  static async blockEmployee(token, employeeId) {
    const response = await fetch(`${API_URL}/admin/employees/${employeeId}/block`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      throw new Error('Failed to block employee');
    }

    return await response.json();
  }

  // Unblock employee (Admin)
  static async unblockEmployee(token, employeeId) {
    const response = await fetch(`${API_URL}/admin/employees/${employeeId}/unblock`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      throw new Error('Failed to unblock employee');
    }

    return await response.json();
  }

  // Delete employee (Admin)
  static async deleteEmployee(token, employeeId) {
    const response = await fetch(`${API_URL}/admin/employees/${employeeId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      throw new Error('Failed to delete employee');
    }

    return await response.json();
  }

  // Get employee profile
  static async getEmployeeProfile(token, employeeId) {
    const response = await fetch(`${API_URL}/employee/profile/${employeeId}`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch profile');
    }

    return await response.json();
  }
}

export default ApiService;