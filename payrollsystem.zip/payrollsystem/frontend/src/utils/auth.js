// Simple authentication utility functions

export const saveUser = (userData) => {
  localStorage.setItem('user', JSON.stringify(userData));
};

export const getUser = () => {
  const userData = localStorage.getItem('user');
  return userData ? JSON.parse(userData) : null;
};

export const removeUser = () => {
  localStorage.removeItem('user');
};

export const isAuthenticated = () => {
  return getUser() !== null;
};

export const isAdmin = () => {
  const user = getUser();
  return user && user.role === 'admin';
};

export const isEmployee = () => {
  const user = getUser();
  return user && user.role === 'employee';
};