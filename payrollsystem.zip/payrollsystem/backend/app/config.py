class Config:
    
    ADMIN_EMAIL = "admin@payroll.com"
    ADMIN_PASSWORD = "admin123"
    
    
    SECRET_KEY = "your-secret-key-here-change-in-production"
    ALGORITHM = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES = 60
    
    
    DATABASE_URL = "sqlite:///./payroll.db"
    
    FULL_TIME_BASE_SALARY = 3000  
    PART_TIME_HOURLY_RATE = 15    
    OVERTIME_HOURLY_RATE = 20     
    
    
    EMPLOYEE_ID_PREFIX = "EMP" 