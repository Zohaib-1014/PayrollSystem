from datetime import datetime, timedelta
from jose import JWTError, jwt
from app.config import Config
import random
import string

class AuthService:    
    @staticmethod
    def verify_admin(email: str, password: str) -> bool:
        return email == Config.ADMIN_EMAIL and password == Config.ADMIN_PASSWORD
    
    @staticmethod
    def create_access_token(data: dict) -> str:
        to_encode = data.copy()
        expire = datetime.utcnow() + timedelta(minutes=Config.ACCESS_TOKEN_EXPIRE_MINUTES)
        to_encode.update({"exp": expire})
        encoded_jwt = jwt.encode(to_encode, Config.SECRET_KEY, algorithm=Config.ALGORITHM)
        return encoded_jwt
    
    @staticmethod
    def verify_token(token: str):
        try:
            payload = jwt.decode(token, Config.SECRET_KEY, algorithms=[Config.ALGORITHM])
            return payload
        except JWTError:
            return None
    
    @staticmethod
    def generate_random_password(length: int = 8) -> str:
        characters = string.ascii_letters + string.digits
        password = ''.join(random.choice(characters) for _ in range(length))
        return password
    
    @staticmethod
    def hash_password(password: str) -> str:
        return password
    
    @staticmethod
    def verify_password(plain_password: str, hashed_password: str) -> bool:
        return plain_password == hashed_password