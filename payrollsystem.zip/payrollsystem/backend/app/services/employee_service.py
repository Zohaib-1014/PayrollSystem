from sqlalchemy.orm import Session
from app.models.database_models import EmployeeDB
from app.models.employee import FullTimeEmployee, PartTimeEmployee
from app.services.auth_services import AuthService
from app.config import Config

class EmployeeService:
    @staticmethod
    def generate_employee_id(db: Session) -> str:
        last_employee = db.query(EmployeeDB).order_by(EmployeeDB.id.desc()).first()
        if last_employee:
            last_number = int(last_employee.employee_id.replace(Config.EMPLOYEE_ID_PREFIX, ""))
            new_number = last_number + 1
        else:
            new_number = 1
        
        employee_id = f"{Config.EMPLOYEE_ID_PREFIX}{new_number:03d}"
        return employee_id
    
    @staticmethod
    def create_employee(db: Session, name: str, email: str, designation: str, hours_worked: float = 0):
        employee_id = EmployeeService.generate_employee_id(db)
        password = AuthService.generate_random_password()
        hashed_password = AuthService.hash_password(password)
        
        db_employee = EmployeeDB(
            employee_id=employee_id,
            name=name,
            email=email,
            password=hashed_password,
            designation=designation,
            hours_worked=hours_worked if designation == "Part-Time" else 0
        )
        
        db.add(db_employee)
        db.commit()
        db.refresh(db_employee)
        
        return {
            "employee_id": employee_id,
            "password": password,
            "name": name,
            "email": email
        }
    
    @staticmethod
    def get_employee_object(db_employee: EmployeeDB):
        if db_employee.designation == "Full-Time":
            emp = FullTimeEmployee(
                db_employee.employee_id,
                db_employee.name,
                db_employee.email
            )
        else: 
            emp = PartTimeEmployee(
                db_employee.employee_id,
                db_employee.name,
                db_employee.email,
                db_employee.hours_worked
            )
        
        emp.set_bonus(db_employee.bonus)
        emp.set_extra_hours(db_employee.extra_hours)
        emp.set_is_blocked(db_employee.is_blocked)
        
        return emp
    
    @staticmethod
    def calculate_employee_salary(db_employee: EmployeeDB) -> float:
        emp = EmployeeService.get_employee_object(db_employee)
        return emp.calculate_salary()
    
    @staticmethod
    def get_salary_breakdown(db_employee: EmployeeDB) -> dict:
        emp = EmployeeService.get_employee_object(db_employee)
        return emp.get_salary_breakdown()