from sqlalchemy import Column, Integer, String, Float, Boolean
from app.database import Base

class EmployeeDB(Base):
    __tablename__ = "employees" 
    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(String, unique=True, index=True)
    name = Column(String)
    email = Column(String, unique=True)
    password = Column(String)
    designation = Column(String)  
    hours_worked = Column(Float, default=0)  
    bonus = Column(Float, default=0)
    extra_hours = Column(Float, default=0)
    is_blocked = Column(Boolean, default=False)