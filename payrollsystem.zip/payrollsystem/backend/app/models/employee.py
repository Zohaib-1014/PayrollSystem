from abc import ABC, abstractmethod
from app.config import Config

class Employee(ABC):
    def __init__(self, employee_id, name, email, designation):
        self.__employee_id = employee_id
        self.__name = name
        self.__email = email
        self.__designation = designation
        self.__bonus = 0
        self.__extra_hours = 0
        self.__is_blocked = False
    
    def get_employee_id(self):
        return self.__employee_id
    
    def get_name(self):
        return self.__name
    
    def get_email(self):
        return self.__email
    
    def get_designation(self):
        return self.__designation
    
    def get_bonus(self):
        return self.__bonus
    
    def get_extra_hours(self):
        return self.__extra_hours
    
    def get_is_blocked(self):
        return self.__is_blocked
    
    def set_bonus(self, bonus):
        self.__bonus = bonus
    
    def set_extra_hours(self, hours):
        self.__extra_hours = hours
    
    def set_is_blocked(self, status):
        self.__is_blocked = status
    
    @abstractmethod
    def calculate_salary(self):
        pass
    
    def set_incentives(self, bonus=0, extra_hours=0):
        """Set incentives with default parameters"""
        self.set_bonus(bonus)
        self.set_extra_hours(extra_hours)


class FullTimeEmployee(Employee):  
    def __init__(self, employee_id, name, email):
        super().__init__(employee_id, name, email, "Full-Time")
        self.__base_salary = Config.FULL_TIME_BASE_SALARY
    
    def get_base_salary(self):
        return self.__base_salary
    
    def calculate_salary(self):
        """Calculate total salary for full-time employee"""
        overtime_pay = self.get_extra_hours() * Config.OVERTIME_HOURLY_RATE
        total_salary = self.__base_salary + self.get_bonus() + overtime_pay
        return total_salary
    
    def get_salary_breakdown(self):
        """Return detailed salary breakdown"""
        return {
            "base_salary": self.__base_salary,
            "bonus": self.get_bonus(),
            "extra_hours": self.get_extra_hours(),
            "overtime_pay": self.get_extra_hours() * Config.OVERTIME_HOURLY_RATE,
            "total_salary": self.calculate_salary()
        }

class PartTimeEmployee(Employee):    
    def __init__(self, employee_id, name, email, hours_worked=0):
        super().__init__(employee_id, name, email, "Part-Time")
        self.__hourly_rate = Config.PART_TIME_HOURLY_RATE
        self.__hours_worked = hours_worked
    
    def get_hourly_rate(self):
        return self.__hourly_rate
    
    def get_hours_worked(self):
        return self.__hours_worked
    
    def set_hours_worked(self, hours):
        self.__hours_worked = hours
    

    def calculate_salary(self):
        base_pay = self.__hours_worked * self.__hourly_rate
        overtime_pay = self.get_extra_hours() * Config.OVERTIME_HOURLY_RATE
        total_salary = base_pay + self.get_bonus() + overtime_pay
        return total_salary
    
    def get_salary_breakdown(self):
        return {
            "hourly_rate": self.__hourly_rate,
            "hours_worked": self.__hours_worked,
            "base_pay": self.__hours_worked * self.__hourly_rate,
            "bonus": self.get_bonus(),
            "extra_hours": self.get_extra_hours(),
            "overtime_pay": self.get_extra_hours() * Config.OVERTIME_HOURLY_RATE,
            "total_salary": self.calculate_salary()
        }