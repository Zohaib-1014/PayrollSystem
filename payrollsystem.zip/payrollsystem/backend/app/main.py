from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database import engine, Base
from app.routes import admin, employee

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Payroll System API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # React dev server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(admin.router)
app.include_router(employee.router)

@app.get("/")
def root():
    return {"message": "Payroll System API is running"}

@app.get("/health")
def health_check():
    return {"status": "healthy"}