from pydantic import BaseModel, EmailStr
from typing import Optional

class EmployeeCreate(BaseModel):
    name: str
    email: EmailStr
    designation: str  
    hours_worked: Optional[float] = 0

class EmployeeResponse(BaseModel):
    id: int
    employee_id: str
    name: str
    email: str
    designation: str
    hours_worked: float
    bonus: float
    extra_hours: float
    is_blocked: bool
    total_salary: float
    
    class Config:
        from_attributes = True

class EmployeeLogin(BaseModel):
    employee_id: str
    password: str

class AdminLogin(BaseModel):
    email: EmailStr
    password: str

class UpdateIncentives(BaseModel):
    bonus: Optional[float] = 0
    extra_hours: Optional[float] = 0
    hours_worked: Optional[float] = None

class EmployeeCredentials(BaseModel):
    employee_id: str
    password: str
    name: str
    email: str