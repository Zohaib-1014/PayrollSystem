from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.schemas.employee_schema import (
    AdminLogin, EmployeeCreate, EmployeeResponse, 
    UpdateIncentives, EmployeeCredentials
)
from app.services.auth_services import AuthService
from app.services.employee_service import EmployeeService
from app.models.database_models import EmployeeDB
from typing import List

router = APIRouter(prefix="/admin", tags=["Admin"])

@router.post("/login")
def admin_login(credentials: AdminLogin):
    if AuthService.verify_admin(credentials.email, credentials.password):
        token = AuthService.create_access_token({"sub": credentials.email, "role": "admin"})
        return {"access_token": token, "token_type": "bearer", "role": "admin"}
    raise HTTPException(status_code=401, detail="Invalid credentials")

@router.post("/employees", response_model=EmployeeCredentials)
def create_employee(employee: EmployeeCreate, db: Session = Depends(get_db)):
    existing = db.query(EmployeeDB).filter(EmployeeDB.email == employee.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Create employee
    credentials = EmployeeService.create_employee(
        db, 
        employee.name, 
        employee.email, 
        employee.designation,
        employee.hours_worked
    )
    
    return credentials

@router.get("/employees", response_model=List[EmployeeResponse])
def get_all_employees(db: Session = Depends(get_db)):
    employees = db.query(EmployeeDB).all()
    response = []
    
    for emp in employees:
        total_salary = EmployeeService.calculate_employee_salary(emp)
        response.append({
            "id": emp.id,
            "employee_id": emp.employee_id,
            "name": emp.name,
            "email": emp.email,
            "designation": emp.designation,
            "hours_worked": emp.hours_worked,
            "bonus": emp.bonus,
            "extra_hours": emp.extra_hours,
            "is_blocked": emp.is_blocked,
            "total_salary": total_salary
        })
    
    return response

@router.put("/employees/{employee_id}/incentives")
def update_incentives(employee_id: str, incentives: UpdateIncentives, db: Session = Depends(get_db)):
    employee = db.query(EmployeeDB).filter(EmployeeDB.employee_id == employee_id).first()
    if not employee:
        raise HTTPException(status_code=404, detail="Employee not found")
    
    employee.bonus = incentives.bonus
    employee.extra_hours = incentives.extra_hours
    
    if incentives.hours_worked is not None and employee.designation == "Part-Time":
        employee.hours_worked = incentives.hours_worked
    
    db.commit()
    
    total_salary = EmployeeService.calculate_employee_salary(employee)
    
    return {"message": "Incentives updated", "total_salary": total_salary}

@router.put("/employees/{employee_id}/block")
def block_employee(employee_id: str, db: Session = Depends(get_db)):
    employee = db.query(EmployeeDB).filter(EmployeeDB.employee_id == employee_id).first()
    if not employee:
        raise HTTPException(status_code=404, detail="Employee not found")
    
    employee.is_blocked = True
    db.commit()
    
    return {"message": "Employee blocked"}

@router.put("/employees/{employee_id}/unblock")
def unblock_employee(employee_id: str, db: Session = Depends(get_db)):
    employee = db.query(EmployeeDB).filter(EmployeeDB.employee_id == employee_id).first()
    if not employee:
        raise HTTPException(status_code=404, detail="Employee not found")
    
    employee.is_blocked = False
    db.commit()
    
    return {"message": "Employee unblocked"}

@router.delete("/employees/{employee_id}")
def delete_employee(employee_id: str, db: Session = Depends(get_db)):
    employee = db.query(EmployeeDB).filter(EmployeeDB.employee_id == employee_id).first()
    if not employee:
        raise HTTPException(status_code=404, detail="Employee not found")
    
    db.delete(employee)
    db.commit()
    
    return {"message": "Employee deleted"}