from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.schemas.employee_schema import EmployeeLogin
from app.services.auth_services import AuthService
from app.services.employee_service import EmployeeService
from app.models.database_models import EmployeeDB

router = APIRouter(prefix="/employee", tags=["Employee"])

@router.post("/login")
def employee_login(credentials: EmployeeLogin, db: Session = Depends(get_db)):
    employee = db.query(EmployeeDB).filter(
        EmployeeDB.employee_id == credentials.employee_id
    ).first()
    
    if not employee:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    if employee.is_blocked:
        raise HTTPException(status_code=403, detail="Account is blocked")
    
    if not AuthService.verify_password(credentials.password, employee.password):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    token = AuthService.create_access_token({
        "sub": employee.employee_id, 
        "role": "employee"
    })
    
    return {
        "access_token": token, 
        "token_type": "bearer", 
        "role": "employee",
        "employee_id": employee.employee_id
    }

@router.get("/profile/{employee_id}")
def get_employee_profile(employee_id: str, db: Session = Depends(get_db)):
    employee = db.query(EmployeeDB).filter(
        EmployeeDB.employee_id == employee_id
    ).first()
    
    if not employee:
        raise HTTPException(status_code=404, detail="Employee not found")
    
    salary_breakdown = EmployeeService.get_salary_breakdown(employee)
    
    return {
        "employee_id": employee.employee_id,
        "name": employee.name,
        "email": employee.email,
        "designation": employee.designation,
        "salary_breakdown": salary_breakdown,
        "is_blocked": employee.is_blocked
    }